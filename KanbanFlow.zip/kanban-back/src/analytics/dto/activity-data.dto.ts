export class ActivityDataDto {
    date: string;
    count: number;
  }
  