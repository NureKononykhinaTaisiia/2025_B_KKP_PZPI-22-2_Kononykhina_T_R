export class ProjectStatsDto {
    id: string;
    name: string;
    tasksCount: number;
    completedTasksCount: number;
    completionRate: number;
  }
  