export class ColumnDistributionDto {
    columnId: string;
    columnTitle: string;
    tasksCount: number;
    percentage: number;
  }
  