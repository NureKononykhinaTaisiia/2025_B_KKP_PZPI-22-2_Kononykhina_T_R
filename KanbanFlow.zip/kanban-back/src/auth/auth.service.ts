// src/auth/auth.service.ts (оновлена версія без верифікації)
import {
  BadRequestException,
  ConflictException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { ConfigService } from '@nestjs/config';
import { UsersService } from '../users/users.service';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { LoginDto } from './dto/login.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { UserDocument } from '../users/schemas/user.schema';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {}

  async register(createUserDto: CreateUserDto): Promise<{ 
    message: string; 
    accessToken: string; 
    user: any 
  }> {
    try {
      // Створюємо користувача (без токена верифікації)
      const user = await this.usersService.create({
        ...createUserDto,
        isVerified: true, 
      });
      
      // Автоматично логінимо користувача після реєстрації
      const payload = { email: user.email, sub: user._id };
      const accessToken = this.jwtService.sign(payload);
      
      // Оновлюємо час останнього входу
      await this.usersService.updateLastLogin(user._id);
      
      return {
        message: 'Користувач успішно зареєстрований і увійшов в систему.',
        accessToken,
        user: {
          id: user._id,
          email: user.email,
          fullName: user.fullName,
          avatarUrl: user.avatarUrl,
          isVerified: user.isVerified,
          createdAt: user.createdAt,
          lastLogin: user.lastLogin,
        },
      };
    } catch (error) {
      if (error instanceof ConflictException) {
        throw error;
      }
      throw new BadRequestException('Помилка при реєстрації користувача');
    }
  }

  async validateUser(email: string, password: string): Promise<any> {
    try {
      const user = await this.usersService.findByEmail(email);
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      
      if (isPasswordValid) {
        const { password, ...result } = user.toObject();
        return result;
      }
      
      return null;
    } catch (error) {
      return null;
    }
  }

  async login(user: UserDocument, loginDto: LoginDto): Promise<{ accessToken: string; user: any }> {
    // Оновлюємо час останнього входу
    await this.usersService.updateLastLogin(user._id);
    
    // Створюємо payload для JWT
    const payload = { email: user.email, sub: user._id };
    
    // Визначаємо час життя токена в залежності від опції "запам'ятати мене"
    const expiresIn = loginDto.rememberMe ? 
      this.configService.get<string>('REFRESH_TOKEN_EXPIRES_IN', '7d') : 
      this.configService.get<string>('JWT_EXPIRES_IN', '24h');
    
    return {
      accessToken: this.jwtService.sign(payload, { expiresIn }),
      user: {
        id: user._id,
        email: user.email,
        fullName: user.fullName,
        avatarUrl: user.avatarUrl,
        isVerified: user.isVerified,
        createdAt: user.createdAt,
        lastLogin: user.lastLogin,
      },
    };
  }

  // Оновлення профілю користувача
  async updateProfile(userId: string, updateProfileDto: UpdateProfileDto): Promise<UserDocument> {
    try {
      // Отримуємо поточного користувача
      const currentUser = await this.usersService.findById(userId);
      
      // Перевіряємо, чи змінюється email і чи існує користувач з таким email
      if (updateProfileDto.email && updateProfileDto.email !== currentUser.email) {
        const existingUser = await this.usersService.findByEmailOptional(updateProfileDto.email);
        if (existingUser && existingUser._id.toString() !== userId) {
          throw new ConflictException('Користувач з таким email вже існує');
        }
      }

      // Створюємо об'єкт для оновлення тільки з переданими полями
      const updateData: Partial<UpdateProfileDto> = {};
      
      if (updateProfileDto.fullName !== undefined) {
        updateData.fullName = updateProfileDto.fullName;
      }
      
      if (updateProfileDto.email !== undefined) {
        updateData.email = updateProfileDto.email;
      }

      // Якщо немає даних для оновлення
      if (Object.keys(updateData).length === 0) {
        throw new BadRequestException('Немає даних для оновлення');
      }

      // Оновлюємо профіль користувача
      return this.usersService.updateProfile(userId, updateData);
    } catch (error) {
      if (error instanceof ConflictException || error instanceof BadRequestException) {
        throw error;
      }
      throw new BadRequestException('Помилка при оновленні профілю');
    }
  }



  // Зміна пароля користувача
  async changePassword(userId: string, changePasswordDto: ChangePasswordDto): Promise<{ message: string }> {
    try {
      const user = await this.usersService.findById(userId);
      
      // Перевіряємо поточний пароль
      const isCurrentPasswordValid = await bcrypt.compare(
        changePasswordDto.currentPassword,
        user.password,
      );
      
      if (!isCurrentPasswordValid) {
        throw new UnauthorizedException('Поточний пароль невірний');
      }
      
      // Хешуємо новий пароль
      const hashedPassword = await bcrypt.hash(changePasswordDto.newPassword, 10);
      
      // Оновлюємо пароль
      await this.usersService.updatePassword(userId, hashedPassword);
      
      return {
        message: 'Пароль успішно змінено!',
      };
    } catch (error) {
      if (error instanceof UnauthorizedException) {
        throw error;
      }
      throw new BadRequestException('Помилка при зміні пароля');
    }
  }

  // Отримання недавніх проектів користувача
  async getRecentProjects(userId: string, limit: number = 3) {
    return this.usersService.getRecentProjects(userId, limit);
  }

  // Видалення облікового запису користувача
  async deleteAccount(userId: string): Promise<{ message: string }> {
    try {
      await this.usersService.deleteAccount(userId);
      return {
        message: 'Обліковий запис успішно видалено',
      };
    } catch (error) {
      throw new BadRequestException('Помилка при видаленні облікового запису');
    }
  }
}