// src/auth/dto/update-profile.dto.ts
import { IsEmail, IsNotEmpty, IsOptional, IsString, MinLength } from 'class-validator';

export class UpdateProfileDto {
  @IsOptional()
  @IsString()
  @IsNotEmpty()
  fullName?: string;
  
  @IsOptional()
  @IsEmail()
  @IsNotEmpty()
  email?: string;
}

