// src/api/api.ts (оновлена версія)
import axios from 'axios';
import { toast } from 'react-hot-toast';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5005/api';

// Create axios instance with base URL
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  // Add timeout to prevent hanging requests
  timeout: 15000,
});

// Add interceptor to append auth token to each request
api.interceptors.request.use(
  (config) => {
    // Get token from localStorage (if available)
    let token;
    
    // Use try-catch to handle localStorage access errors (e.g., in SSR context)
    try {
      token = localStorage.getItem('authToken');
    } catch (error) {
      console.error('Error accessing localStorage:', error);
    }
    
    // If token exists, add it to request headers
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Check if error has response
    if (error.response) {
      // Check for 401 Unauthorized error
      if (error.response.status === 401) {
        try {
          // Remove token and redirect to login page
          localStorage.removeItem('authToken');
          
          // Only redirect in browser environment
          if (typeof window !== 'undefined') {
            toast.error('Сесія закінчилась. Будь ласка, увійдіть знову.');
            window.location.href = '/auth/login';
          }
        } catch (e) {
          console.error('Error handling unauthorized response:', e);
        }
      } else if (error.response.status === 500) {
        toast.error('Сервер тимчасово недоступний. Спробуйте пізніше.');
      }
      
      
      
    } else if (error.request) {
      // The request was made but no response was received
      toast.error('Немає відповіді від сервера. Перевірте підключення до інтернету.');
     
    } else {
      // Something happened in setting up the request
      console.error('Request setup error:', error.message);
    }
    
    return Promise.reject(error);
  }
);

// Export API modules for various resources
export const auth = {
  register: (data: { email: string; password: string; fullName: string }) => 
    api.post('/auth/register', data),
  
  login: (data: { email: string; password: string; rememberMe: boolean }) => 
    api.post('/auth/login', data),
  
  me: () => api.get('/auth/me'),
  
  // Нові методи для роботи з профілем
  
  // Оновлення даних профілю користувача
  updateProfile: (data: { fullName?: string; email?: string }) => 
    api.put('/auth/profile', data),
  
  // Зміна пароля
  changePassword: (data: { currentPassword: string; newPassword: string }) => 
    api.post('/auth/change-password', data),
  
  // Завантаження аватара
  uploadAvatar: (formData: FormData) => 
    api.post('/auth/avatar', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }),
  
  // Видалення аватара
  deleteAvatar: () => api.delete('/auth/avatar'),
  
  // Видалення облікового запису
  deleteAccount: () => api.delete('/auth/account'),
  
  // Отримання недавніх проектів користувача
  getRecentProjects: () => api.get('/auth/recent-projects'),
};

export const projects = {
  getAll: (params?: { status?: string; sort?: string }) => 
    api.get('/projects', { params }),
  
  getById: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.get(`/projects/${id}`);
  },
  
  getUserProjects: (limit?: number) => {
    const params = limit ? { limit } : undefined;
    return api.get('/projects/user', { params });
  },
  
  create: (data: { name: string; description?: string }) => 
    api.post('/projects', data),
  
  update: (id: string, data: { name: string; description?: string }) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.put(`/projects/${id}`, data);
  },
  
  delete: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.delete(`/projects/${id}`);
  },
  
  updateColumnOrder: (id: string, columnOrder: string[]) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.patch(`/projects/${id}/column-order`, { columnOrder });
  },
};

export const columns = {
  getAll: (projectId: string) => {
    // Validate projectId before making request
    if (!projectId || projectId === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.get('/columns', { params: { projectId } });
  },
  
  getById: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid column ID'));
    }
    return api.get(`/columns/${id}`);
  },
  
  create: (data: { title: string; projectId: string }) => {
    // Validate projectId before making request
    if (!data.projectId || data.projectId === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.post('/columns', data);
  },
  
  update: (id: string, data: { title: string }) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid column ID'));
    }
    return api.put(`/columns/${id}`, data);
  },
  
  delete: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid column ID'));
    }
    return api.delete(`/columns/${id}`);
  },
  
  updateTaskOrder: (id: string, taskIds: string[]) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid column ID'));
    }
    return api.patch(`/columns/${id}/task-order`, { taskIds });
  },
};

export const tasks = {
  getAll: (projectId: string) => {
    // Validate projectId before making request
    if (!projectId || projectId === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.get('/tasks', { params: { projectId } });
  },
  
  getById: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid task ID'));
    }
    return api.get(`/tasks/${id}`);
  },
  
  create: (data: {
    title: string;
    description?: string;
    columnId: string;
    projectId: string;
    deadline?: string;
    labels?: string[];
  }) => {
    // Validate ids before making request
    if (!data.projectId || data.projectId === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    if (!data.columnId || data.columnId === 'undefined') {
      return Promise.reject(new Error('Invalid column ID'));
    }
    return api.post('/tasks', data);
  },
  
  update: (id: string, data: {
    title?: string;
    description?: string;
    columnId?: string;
    deadline?: string;
    labels?: string[];
  }) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid task ID'));
    }
    if (data.columnId && data.columnId === 'undefined') {
      return Promise.reject(new Error('Invalid column ID'));
    }
    return api.put(`/tasks/${id}`, data);
  },
  
  delete: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid task ID'));
    }
    return api.delete(`/tasks/${id}`);
  },
  
  move: (id: string, targetColumnId: string) => {
    // Validate ids before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid task ID'));
    }
    if (!targetColumnId || targetColumnId === 'undefined') {
      return Promise.reject(new Error('Invalid target column ID'));
    }
    return api.patch(`/tasks/${id}/move`, { targetColumnId });
  },
  
  getUpcoming: (days: number = 7) => 
    api.get('/tasks/upcoming', { params: { days } }),
  
  getOverdue: () => api.get('/tasks/overdue'),
};

export const notifications = {
  getAll: () => api.get('/notifications'),
  
  getUnread: () => api.get('/notifications/unread'),
  
  markAsRead: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid notification ID'));
    }
    return api.post(`/notifications/${id}/read`);
  },
  
  markAllAsRead: () => api.post('/notifications/read-all'),
  
  delete: (id: string) => {
    // Validate id before making request
    if (!id || id === 'undefined') {
      return Promise.reject(new Error('Invalid notification ID'));
    }
    return api.delete(`/notifications/${id}`);
  },
};

export const analytics = {
  getStatistics: (timeRange = 'month', startDate?: string, endDate?: string) => {
    const params: Record<string, string> = { timeRange };
    if (timeRange === 'custom' && startDate && endDate) {
      params.startDate = startDate;
      params.endDate = endDate;
    }
    return api.get('/analytics/statistics', { params });
  },
  
  getActivity: (timeRange = 'month', startDate?: string, endDate?: string) => {
    const params: Record<string, string> = { timeRange };
    if (timeRange === 'custom' && startDate && endDate) {
      params.startDate = startDate;
      params.endDate = endDate;
    }
    return api.get('/analytics/activity', { params });
  },
  
  getTasksDistribution: (projectId: string) => {
    // Validate projectId before making request
    if (!projectId || projectId === 'undefined') {
      return Promise.reject(new Error('Invalid project ID'));
    }
    return api.get(`/analytics/projects/${projectId}/distribution`);
  },
  
  getCompletionVelocity: (timeRange = 'month', startDate?: string, endDate?: string) => {
    const params: Record<string, string> = { timeRange };
    if (timeRange === 'custom' && startDate && endDate) {
      params.startDate = startDate;
      params.endDate = endDate;
    }
    return api.get('/analytics/velocity', { params });
  },
};

export default api