'use client';

import { useState, useEffect } from 'react';
import { DragDropContext, DropResult, Droppable } from '@hello-pangea/dnd';
import Column from './Column';
import CreateColumnModal from './CreateColumnModal';
import styles from './Board.module.css';
import { Button } from '../ui/Button/Button';
import { columns as columnsApi, tasks as tasksApi, projects as projectsApi } from '@/api/api';

// Типи для даних дошки
export interface Task {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  deadline?: string;
  labels?: string[];
}

export interface Column {
  id: string;
  title: string;
  taskIds: string[];
}

export interface KanbanBoard {
  id: string;
  title: string;
  columns: {
    [key: string]: Column;
  };
  columnOrder: string[];
  tasks: {
    [key: string]: Task;
  };
}

interface BoardProps {
  board: KanbanBoard;
  onBoardChange: (board: KanbanBoard) => void;
  onAddColumn: (title: string) => Promise<void>;
  onAddTask: (columnId: string, title: string, desc: string, deadline?: string) => Promise<void>;
  onUpdateTask: (taskId: string, updated: Partial<Task>) => Promise<void>;
  onDeleteTask: (taskId: string, columnId: string) => Promise<void>;
}

const Board: React.FC<BoardProps> = ({
    board,
    onBoardChange,
    onAddColumn,
    onAddTask,
    onUpdateTask,
    onDeleteTask
  }) => {  const [modalOpen, setModalOpen] = useState(false);
  const [isSticky, setIsSticky] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Функція для витягування справжнього ID з droppableId
  const extractRealId = (droppableId: string): string => {
    if (droppableId.startsWith('column-')) {
      return droppableId.replace('column-', '');
    }
    return droppableId;
  };

  // Функція для витягування справжнього ID з draggableId
  const extractRealDraggableId = (draggableId: string): string => {
    if (draggableId.startsWith('column-')) {
      return draggableId.replace('column-', '');
    }
    return draggableId;
  };

  // Обробляємо подію прокрутки для фіксації заголовка
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 50) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Обробка переміщення задач між колонками
  const handleDragEnd = async (result: DropResult) => {
    const { destination, source, draggableId, type } = result;

    // Якщо немає призначення або перетягування на те ж місце
    if (!destination) return;
    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) {
      return;
    }

    // Якщо переміщуємо колонку
    if (type === 'column') {
      const realDraggableId = extractRealDraggableId(draggableId);
      const newColumnOrder = Array.from(board.columnOrder);
      
      // Знаходимо індекс колонки в columnOrder
      const sourceIndex = newColumnOrder.indexOf(realDraggableId);
      if (sourceIndex === -1) {
        console.error('Column not found in columnOrder:', realDraggableId);
        return;
      }

      newColumnOrder.splice(sourceIndex, 1);
      newColumnOrder.splice(destination.index, 0, realDraggableId);

      const newBoard = {
        ...board,
        columnOrder: newColumnOrder,
      };

      // Оновлюємо стан UI перед запитом для миттєвого відображення змін
      onBoardChange(newBoard);

      try {
        // Зберігаємо оновлений порядок колонок на сервер
        await projectsApi.updateColumnOrder(board.id, newColumnOrder);
      } catch (error) {
        console.error('Error updating column order:', error);
        // В разі помилки повертаємо початковий стан
        onBoardChange(board);
      }
      
      return;
    }

    // Витягуємо справжні ID колонок
    const sourceColumnId = extractRealId(source.droppableId);
    const destinationColumnId = extractRealId(destination.droppableId);

    // Отримуємо початкову і кінцеву колонки
    const startColumn = board.columns[sourceColumnId];
    const finishColumn = board.columns[destinationColumnId];

    // Перевіряємо, чи існують колонки
    if (!startColumn || !finishColumn) {
      console.error('Missing column data:', { 
        sourceColumnId, 
        destinationColumnId,
        availableColumns: Object.keys(board.columns),
        originalIds: { source: source.droppableId, destination: destination.droppableId }
      });
      return;
    }

    // Переміщення всередині однієї колонки
    if (startColumn === finishColumn) {
      const newTaskIds = Array.from(startColumn.taskIds || []);
      newTaskIds.splice(source.index, 1);
      newTaskIds.splice(destination.index, 0, draggableId);

      const newColumn = {
        ...startColumn,
        taskIds: newTaskIds,
      };

      const newBoard = {
        ...board,
        columns: {
          ...board.columns,
          [sourceColumnId]: newColumn,
        },
      };

      // Оновлюємо стан UI перед запитом для миттєвого відображення змін
      onBoardChange(newBoard);

      try {
        // Зберігаємо оновлений порядок задач на сервер
        await columnsApi.updateTaskOrder(sourceColumnId, newTaskIds);
      } catch (error) {
        console.error('Error updating task order:', error);
        // В разі помилки повертаємо початковий стан
        onBoardChange(board);
      }
      
      return;
    }

    // Переміщення між колонками
    const startTaskIds = Array.from(startColumn.taskIds || []);
    startTaskIds.splice(source.index, 1);
    const newStartColumn = {
      ...startColumn,
      taskIds: startTaskIds,
    };

    const finishTaskIds = Array.from(finishColumn.taskIds || []);
    finishTaskIds.splice(destination.index, 0, draggableId);
    const newFinishColumn = {
      ...finishColumn,
      taskIds: finishTaskIds,
    };

    const newBoard = {
      ...board,
      columns: {
        ...board.columns,
        [sourceColumnId]: newStartColumn,
        [destinationColumnId]: newFinishColumn,
      },
    };

    // Оновлюємо стан UI перед запитом для миттєвого відображення змін
    onBoardChange(newBoard);

    try {
      // Зберігаємо переміщення задачі між колонками на сервер
      await tasksApi.move(draggableId, destinationColumnId);
      
      // Оновлюємо порядок задач у колонках
      await columnsApi.updateTaskOrder(sourceColumnId, startTaskIds);
      await columnsApi.updateTaskOrder(destinationColumnId, finishTaskIds);
    } catch (error) {
      console.error('Error moving task between columns:', error);
      // В разі помилки повертаємо початковий стан
      onBoardChange(board);
    }
  };

  // Додавання нової колонки
  // const handleAddColumn = async (title: string) => {
  //   setIsLoading(true);
    
  //   try {
  //     // Створюємо нову колонку на сервері
  //     const response = await columnsApi.create({
  //       title,
  //       projectId: board.id,
  //     });
      
  //     const newColumn = response.data;
      
  //     // Оновлюємо локальний стан з відповіддю від сервера
  //     const newBoard = {
  //       ...board,
  //       columns: {
  //         ...board.columns,
  //         [newColumn.id]: {
  //           id: newColumn.id,
  //           title: newColumn.title,
  //           taskIds: newColumn.taskIds || [],
  //         },
  //       },
  //       columnOrder: [...board.columnOrder, newColumn.id],
  //     };
      
  //     onBoardChange(newBoard);
  //     setModalOpen(false);
  //   } catch (error) {
  //     console.error('Error adding column:', error);
  //     // Показуємо повідомлення про помилку користувачеві
  //     alert('Помилка при створенні колонки. Спробуйте ще раз.');
  //   } finally {
  //     setIsLoading(false);
  //   }
  // };

  // Видалення колонки
  const handleDeleteColumn = async (columnId: string) => {
    // Оновлюємо локальний стан для миттєвої зміни UI
    const updatedColumns = { ...board.columns };
    const columnToDelete = updatedColumns[columnId];
    
    // Видаляємо задачі з цієї колонки
    const updatedTasks = { ...board.tasks };
    if (columnToDelete && columnToDelete.taskIds) {
      columnToDelete.taskIds.forEach(taskId => {
        delete updatedTasks[taskId];
      });
    }
    
    delete updatedColumns[columnId];
    const newColumnOrder = board.columnOrder.filter(id => id !== columnId);

    const newBoard = {
      ...board,
      columns: updatedColumns,
      columnOrder: newColumnOrder,
      tasks: updatedTasks,
    };

    onBoardChange(newBoard);

    try {
      // Видаляємо колонку на сервері
      await columnsApi.delete(columnId);
    } catch (error) {
      console.error('Error deleting column:', error);
      // В разі помилки повертаємо початковий стан
      onBoardChange(board);
    }
  };

  // Додавання нової задачі в колонку
  // const handleAddTask = async (columnId: string, taskTitle: string, taskDescription: string, deadline?: string) => {
  //   try {
  //     // Створюємо нову задачу на сервері
  //     const response = await tasksApi.create({
  //       title: taskTitle,
  //       description: taskDescription,
  //       columnId: columnId,
  //       projectId: board.id,
  //       deadline: deadline,
  //     });

  //     const newTask = response.data;

  //     // Отримуємо поточну колонку
  //     const column = board.columns[columnId];
      
  //     // Перевіряємо, чи існує колонка
  //     if (!column) {
  //       console.error('Column not found:', columnId);
  //       throw new Error('Колонка не знайдена');
  //     }
      
  //     // Оновлюємо локальний стан з відповіддю від сервера
  //     const newBoard = {
  //       ...board,
  //       tasks: {
  //         ...board.tasks,
  //         [newTask.id]: {
  //           id: newTask.id,
  //           title: newTask.title,
  //           description: newTask.description || '',
  //           createdAt: newTask.createdAt,
  //           deadline: newTask.deadline || undefined,
  //           labels: newTask.labels || [],
  //         },
  //       },
  //       columns: {
  //         ...board.columns,
  //         [columnId]: {
  //           ...column,
  //           taskIds: [...(column.taskIds || []), newTask.id],
  //         },
  //       },
  //     };

  //     onBoardChange(newBoard);
  //   } catch (error) {
  //     console.error('Error adding task:', error);
  //     throw error; // Re-throw to handle in Column component
  //   }
  // };

  // Оновлення існуючої задачі
  // const handleUpdateTask = async (taskId: string, updatedTask: Partial<Task>) => {
  //   const task = board.tasks[taskId];
    
  //   if (!task) {
  //     console.error('Task not found:', taskId);
  //     return;
  //   }
    
  //   // Оновлюємо локальний стан для миттєвої зміни UI
  //   const newBoard = {
  //     ...board,
  //     tasks: {
  //       ...board.tasks,
  //       [taskId]: {
  //         ...task,
  //         ...updatedTask,
  //       },
  //     },
  //   };

  //   onBoardChange(newBoard);

  //   try {
  //     // Оновлюємо задачу на сервері
  //     await tasksApi.update(taskId, updatedTask);
  //   } catch (error) {
  //     console.error('Error updating task:', error);
  //     // В разі помилки повертаємо початковий стан
  //     onBoardChange(board);
  //   }
  // };

  // Видалення задачі
  // const handleDeleteTask = async (taskId: string, columnId: string) => {
  //   const column = board.columns[columnId];
    
  //   if (!column) {
  //     console.error('Column not found:', columnId);
  //     return;
  //   }
    
  //   // Оновлюємо локальний стан для миттєвої зміни UI
  //   const newTaskIds = (column.taskIds || []).filter(id => id !== taskId);

  //   const updatedTasks = { ...board.tasks };
  //   delete updatedTasks[taskId];

  //   const newBoard = {
  //     ...board,
  //     tasks: updatedTasks,
  //     columns: {
  //       ...board.columns,
  //       [columnId]: {
  //         ...column,
  //         taskIds: newTaskIds,
  //       },
  //     },
  //   };

  //   onBoardChange(newBoard);

  //   try {
  //     // Видаляємо задачу на сервері
  //     await tasksApi.delete(taskId);
  //   } catch (error) {
  //     console.error('Error deleting task:', error);
  //     // В разі помилки повертаємо початковий стан
  //     onBoardChange(board);
  //   }
  // };

  const headerClasses = [
    styles.boardHeader,
    isSticky ? styles.sticky : '',
  ].join(' ');

  return (
    <div className={styles.boardContainer}>
      <div className={headerClasses}>
        <h1 className={styles.boardTitle}>{board.title}</h1>
        <div className={styles.boardActions}>
          <Button 
            variant="primary" 
            onClick={() => setModalOpen(true)}
            leftIcon={
              <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" strokeWidth="2" fill="none">
                <path d="M12 5v14M5 12h14" />
              </svg>
            }
            isLoading={isLoading}
          >
            Додати колонку
          </Button>
        </div>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="all-columns" direction="horizontal" type="column">
          {(provided) => (
            <div 
              className={styles.boardContent}
              {...provided.droppableProps}
              ref={provided.innerRef}
            >
              {board.columnOrder.map((columnId, index) => {
                const column = board.columns[columnId];
                
                // Пропускаємо відсутні колонки
                if (!column) {
                  console.warn(`Column with ID ${columnId} not found`);
                  return null;
                }
                
                // Переконуємося, що taskIds існує і є масивом
                const taskIds = column.taskIds || [];
                
                // Фільтруємо тільки існуючі задачі
                const tasks = taskIds
                  .map(taskId => board.tasks[taskId])
                  .filter(Boolean);

                return (
                  <Column
                    key={column.id} // Використовуємо column.id як ключ
                    column={column}
                    tasks={tasks}
                    index={index}
                    onAddTask={onAddTask}
                    onUpdateTask={onUpdateTask}
                    onDeleteTask={onDeleteTask}
                    onDeleteColumn={handleDeleteColumn}
              
                  />
                );
              })}
              {provided.placeholder}
              
              <div className={styles.addColumnPlaceholder}>
                <Button 
                  variant="ghost" 
                  onClick={() => setModalOpen(true)}
                  leftIcon={
                    <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" strokeWidth="2" fill="none">
                      <path d="M12 5v14M5 12h14" />
                    </svg>
                  }
                >
                  Додати колонку
                </Button>
              </div>
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <CreateColumnModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onAddColumn={onAddColumn}
        
      />
    </div>
  );
};

export default Board;