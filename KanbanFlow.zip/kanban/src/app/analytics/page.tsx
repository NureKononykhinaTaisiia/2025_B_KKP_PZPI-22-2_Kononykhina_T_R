// src/app/analytics/page.tsx
'use client';

import { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import {
  format,
  parseISO,
  isWithinInterval,
  startOfDay,
  endOfDay,
  isAfter,
  isBefore,
  addDays,
} from 'date-fns';
import { uk } from 'date-fns/locale';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/Button/Button';
import { analytics, auth, tasks as tasksApi, projects as projectsApi } from '@/api/api';
import { toast } from 'react-hot-toast';
import styles from './page.module.css';

// Типы данных
interface Project {
  id: string;
  name: string;
  tasksCount: number;
  completedTasksCount: number;
  columnsCount: number;
  createdAt: string;
  updatedAt: string;
  // Новые поля для аналитики
  filteredTasksCount?: number;
  filteredCompletedTasksCount?: number;
  completionRate?: number;
}

interface Task {
  id: string;
  title: string;
  projectId: string;
  projectName: string;
  createdAt: string;
  deadline: string | null;
  completed: boolean;
  columnId: string;
  columnName: string;
}

interface User {
  id: string;
  fullName: string;
  email: string;
  avatarUrl: string;
}

interface Statistics {
  totalTasks: number;
  completedTasks: number;
  completionRate: number;
  overdueTasks: number;
  upcomingDeadlines: number;
  projectsData: Project[];
}

interface RecentProject {
  id: string;
  name: string;
}

// Типы для фільтрації
type TimeFilter = 'all' | 'week' | 'month' | 'custom';

// Интерфейсы для данных API
interface ApiStatistics {
  totalTasks: number;
  completedTasks: number;
  completionRate: number;
  overdueTasks: number;
  upcomingDeadlines: number;
  projects: {
    id: string;
    name: string;
    tasksCount: number;
    completedTasksCount: number;
    columnsCount: number;
    createdAt: string;
    updatedAt: string;
    filteredTasksCount: number;
    filteredCompletedTasksCount: number;
    completionRate: number;
  }[];
}

export default function AnalyticsPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [recentProjects, setRecentProjects] = useState<RecentProject[]>([]);
  const [statistics, setStatistics] = useState<Statistics | null>(null);
  const [upcomingTasks, setUpcomingTasks] = useState<Task[]>([]);
  const [overdueTasks, setOverdueTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('month');
  const [customDateRange, setCustomDateRange] = useState<{ start: string; end: string }>({
    start: format(new Date(new Date().setDate(new Date().getDate() - 30)), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd'),
  });
  
  // Функция для выхода из системы
  const handleLogout = () => {
    localStorage.removeItem('authToken');
    router.push('/auth/login');
  };
  
  // Получаем данные о пользователе
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        // Перевіряємо авторизацію
        const token = localStorage.getItem('authToken');
        if (!token) {
          router.push('/auth/login');
          return;
        }

        // Отримуємо дані користувача
        const userResponse = await auth.me();
        setUser(userResponse.data);
        
        // Спробуємо отримати проекти користувача через різні ендпоінти
        let projects = [];
        
        try {
          // Спочатку спробуємо через getUserProjects
          const userProjectsResponse = await projectsApi.getUserProjects();
          projects = userProjectsResponse.data || [];
        } catch (userProjectsError) {
          console.log('getUserProjects failed, trying getAll:', userProjectsError);
          
          try {
            // Якщо не вдалося, спробуємо через getAll
            const allProjectsResponse = await projectsApi.getAll();
            projects = allProjectsResponse.data || [];
          } catch (allProjectsError) {
            console.log('getAll projects also failed:', allProjectsError);
            
            try {
              // Останній шанс - спробуємо через recent projects
              const recentProjectsResponse = await auth.getRecentProjects();
              projects = recentProjectsResponse.data || [];
              console.log('Using recent projects as fallback');
            } catch (recentError) {
              console.log('All project endpoints failed:', recentError);
              projects = [];
            }
          }
        }
        
        // Встановлюємо недавні проекти (беремо перші 5)
        setRecentProjects(projects.slice(0, 5));
        
      } catch (error) {
        console.error('Error fetching user data:', error);
                  //@ts-ignore
        if (error?.response?.status === 401) {
          localStorage.removeItem('authToken');
          toast.error('Сесія закінчилась. Перенаправляємо на сторінку входу...');
          router.push('/auth/login');
        } else {
          toast.error('Помилка при завантаженні даних користувача');
        }
      }
    };
    
    fetchUserData();
  }, [router]);
  
  // Загрузка аналитических данных при изменении фильтра времени
  useEffect(() => {
    const fetchAnalyticsData = async () => {
      if (!user) return;
      
      setIsLoading(true);
      
      try {
        console.log(`Fetching analytics for timeFilter: ${timeFilter}`);
        
        // Спочатку отримуємо проекти користувача
        let userProjects = [];
        
        try {
          // Спробуємо отримати проекти користувача через різні ендпоінти
          try {
            const userProjectsResponse = await projectsApi.getUserProjects();
            userProjects = userProjectsResponse.data || [];
          } catch (userProjectsError) {
            console.log('getUserProjects failed, trying getAll:', userProjectsError);
            
            try {
              const allProjectsResponse = await projectsApi.getAll();
              userProjects = allProjectsResponse.data || [];
            } catch (allProjectsError) {
              console.log('getAll projects also failed:', allProjectsError);
              userProjects = [];
            }
          }
          
          console.log(`Found ${userProjects.length} user projects`);
        } catch (projectsError) {
          console.error('Error fetching user projects:', projectsError);
          userProjects = [];
        }
        
        // Якщо немає проектів, встановлюємо пусті дані
        if (userProjects.length === 0) {
          setStatistics({
            totalTasks: 0,
            completedTasks: 0,
            completionRate: 0,
            overdueTasks: 0,
            upcomingDeadlines: 0,
            projectsData: []
          });
          setUpcomingTasks([]);
          setOverdueTasks([]);
          
          console.log('No user projects found, setting empty analytics');
        } else {
          // Замість використання API аналітики, отримаємо задачі безпосередньо з проектів користувача
          const allTasks: any[] = [];
          const projectsStats: any[] = [];
          
          for (const project of userProjects) {
            try {
              const projectTasksResponse = await tasksApi.getAll(project.id);
              const projectTasks = projectTasksResponse.data || [];
              
              console.log(`Project ${project.name}: ${projectTasks.length} tasks`);
              
              // Додаємо назву проекту до кожної задачі
              const tasksWithProjectName = projectTasks.map((task: any) => ({
                ...task,
                projectName: project.name,
                projectId: project.id
              }));
              
              allTasks.push(...tasksWithProjectName);
              
              // Рахуємо статистику по проекту
              // Припускаємо що завершені задачі мають columnName що містить "готово", "done", "завершено"
              const completedTasks = projectTasks.filter((task: any) => 
                task.columnName && (
                  task.columnName.toLowerCase().includes('готово') ||
                  task.columnName.toLowerCase().includes('done') ||
                  task.columnName.toLowerCase().includes('завершено') ||
                  task.columnName.toLowerCase().includes('complete')
                )
              );
              
              const completionRate = projectTasks.length > 0 
                ? Math.round((completedTasks.length / projectTasks.length) * 100)
                : 0;
              
              projectsStats.push({
                id: project.id,
                name: project.name,
                tasksCount: projectTasks.length,
                completedTasksCount: completedTasks.length,
                columnsCount: 0, // Не маємо інформації про колонки
                createdAt: project.createdAt || new Date().toISOString(),
                updatedAt: project.updatedAt || new Date().toISOString(),
                filteredTasksCount: projectTasks.length,
                filteredCompletedTasksCount: completedTasks.length,
                completionRate: completionRate
              });
              
            } catch (projectError) {
              console.error(`Error fetching tasks for project ${project.name}:`, projectError);
                        //@ts-ignore
              if (projectError?.response?.status === 401) {
                localStorage.removeItem('authToken');
                toast.error('Сесія закінчилась. Перенаправляємо на сторінку входу...');
                router.push('/auth/login');
                return;
              }
            }
          }
          
          // Фільтруємо задачі по часовому діапазону якщо потрібно
          let filteredTasks = allTasks;
          if (timeFilter !== 'all') {
            const now = new Date();
            let startDate: Date;
            
            switch (timeFilter) {
              case 'week':
                startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                break;
              case 'month':
                startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                break;
              case 'custom':
                startDate = new Date(customDateRange.start);
                const endDate = new Date(customDateRange.end);
                filteredTasks = allTasks.filter(task => {
                  const taskDate = new Date(task.createdAt);
                  return taskDate >= startDate && taskDate <= endDate;
                });
                break;
              default:
                startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            }
            
            if (timeFilter !== 'custom') {
              filteredTasks = allTasks.filter(task => {
                const taskDate = new Date(task.createdAt);
                return taskDate >= startDate;
              });
            }
          }
          
          // Рахуємо загальну статистику
          const completedTasks = filteredTasks.filter((task: any) => 
            task.columnName && (
              task.columnName.toLowerCase().includes('готово') ||
              task.columnName.toLowerCase().includes('done') ||
              task.columnName.toLowerCase().includes('завершено') ||
              task.columnName.toLowerCase().includes('complete')
            )
          );
          
          // Рахуємо прострочені задачі
          const now = new Date();
          const overdue = filteredTasks.filter((task: any) => 
            task.deadline && 
            new Date(task.deadline) < now && 
            !completedTasks.some((ct: any) => ct.id === task.id)
          );
          
          // Рахуємо наближені дедлайни (7 днів)
          const nextWeek = new Date();
          nextWeek.setDate(now.getDate() + 7);
          
          const upcoming = filteredTasks.filter((task: any) => 
            task.deadline && 
            new Date(task.deadline) > now && 
            new Date(task.deadline) <= nextWeek && 
            !completedTasks.some((ct: any) => ct.id === task.id)
          );
          
          const completionRate = filteredTasks.length > 0 
            ? Math.round((completedTasks.length / filteredTasks.length) * 100)
            : 0;
          
          setStatistics({
            totalTasks: filteredTasks.length,
            completedTasks: completedTasks.length,
            completionRate: completionRate,
            overdueTasks: overdue.length,
            upcomingDeadlines: upcoming.length,
            projectsData: projectsStats.sort((a, b) => b.completionRate - a.completionRate)
          });
          
          // Встановлюємо наближені та прострочені задачі
          setUpcomingTasks(upcoming.slice(0, 10)); // Показуємо максимум 10
          setOverdueTasks(overdue.slice(0, 10)); // Показуємо максимум 10
          
          console.log(`Analytics calculated: ${filteredTasks.length} total tasks, ${completedTasks.length} completed, ${overdue.length} overdue, ${upcoming.length} upcoming`);
        }
        
      } catch (error) {
        console.error('Error fetching analytics data:', error);
                  //@ts-ignore
        if (error?.response?.status === 401) {
          localStorage.removeItem('authToken');
          toast.error('Сесія закінчилась. Перенаправляємо на сторінку входу...');
          router.push('/auth/login');
        } else {
          toast.error('Помилка при завантаженні аналітики');
          
          // Встановлюємо пусті дані при помилці
          setStatistics({
            totalTasks: 0,
            completedTasks: 0,
            completionRate: 0,
            overdueTasks: 0,
            upcomingDeadlines: 0,
            projectsData: []
          });
          setUpcomingTasks([]);
          setOverdueTasks([]);
        }
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchAnalyticsData();
  }, [timeFilter, customDateRange, user, router]);
  
  // Форматування дати
  const formatDate = (dateString: string) => {
    try {
      return format(parseISO(dateString), 'dd.MM.yyyy', { locale: uk });
    } catch (error) {
      console.error('Error formatting date:', dateString, error);
      return dateString;
    }
  };
  
  // Відображення заглушки під час завантаження
  if (isLoading) {
    return (
      <MainLayout 
        user={user || undefined} 
        recentProjects={recentProjects}
        onLogout={handleLogout}
      >
        <div className={styles.loadingContainer}>
          <div className={styles.spinner}></div>
          <p>Завантаження аналітики...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      user={user || undefined} 
      recentProjects={recentProjects}
      onLogout={handleLogout}
    >
      <div className={styles.analyticsContainer}>
        <div className={styles.analyticsHeader}>
          <div className={styles.analyticsTitle}>
            <h1>Аналітика</h1>
          </div>
          
          <div className={styles.filterControls}>
            <div className={styles.timeFilterLabel}>
              Період:
            </div>
            <div className={styles.timeFilterButtons}>
              <Button 
                variant={timeFilter === 'week' ? 'primary' : 'outline'} 
                size="sm"
                onClick={() => setTimeFilter('week')}
              >
                Тиждень
              </Button>
              <Button 
                variant={timeFilter === 'month' ? 'primary' : 'outline'} 
                size="sm"
                onClick={() => setTimeFilter('month')}
              >
                Місяць
              </Button>
              <Button 
                variant={timeFilter === 'all' ? 'primary' : 'outline'} 
                size="sm"
                onClick={() => setTimeFilter('all')}
              >
                Всі
              </Button>
              {/* <Button 
                variant={timeFilter === 'custom' ? 'primary' : 'outline'} 
                size="sm"
                onClick={() => setTimeFilter('custom')}
              >
                Інший...
              </Button> */}
            </div>
            
            {timeFilter === 'custom' && (
              <div className={styles.customDateRange}>
                <div className={styles.dateRangeInputs}>
                  <div className={styles.dateInput}>
                    <label htmlFor="start-date">Від:</label>
                    <input
                      id="start-date"
                      type="date"
                      value={customDateRange.start}
                      onChange={(e) => setCustomDateRange({
                        ...customDateRange,
                        start: e.target.value,
                      })}
                    />
                  </div>
                  <div className={styles.dateInput}>
                    <label htmlFor="end-date">До:</label>
                    <input
                      id="end-date"
                      type="date"
                      value={customDateRange.end}
                      onChange={(e) => setCustomDateRange({
                        ...customDateRange,
                        end: e.target.value,
                      })}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {statistics && (
          <div className={styles.analyticsGrid}>
            {/* Карточки зі статистикою */}
            <div className={styles.statsCards}>
              <div className={styles.statsCard}>
                <div className={styles.statsIconContainer}>
                  <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
                    <rect x="3" y="3" width="7" height="7" rx="1" />
                    <rect x="14" y="3" width="7" height="7" rx="1" />
                    <rect x="14" y="14" width="7" height="7" rx="1" />
                    <rect x="3" y="14" width="7" height="7" rx="1" />
                  </svg>
                </div>
                <div className={styles.statsContent}>
                  <div className={styles.statsValue}>{statistics.totalTasks}</div>
                  <div className={styles.statsLabel}>Всього задач</div>
                </div>
              </div>
              
              {/* <div className={styles.statsCard}>
                <div className={styles.statsIconContainer}>
                  <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                    <polyline points="22 4 12 14.01 9 11.01" />
                  </svg>
                </div>
                <div className={styles.statsContent}>
                  <div className={styles.statsValue}>{statistics.completedTasks}</div>
                  <div className={styles.statsLabel}>Завершено задач</div>
                </div>
              </div> */}
              
              <div className={styles.statsCard}>
                <div className={styles.statsIconContainer}>
                  <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                  </svg>
                </div>
                <div className={styles.statsContent}>
                  <div className={styles.statsValue}>{statistics.upcomingDeadlines}</div>
                  <div className={styles.statsLabel}>Наближаються дедлайни</div>
                </div>
              </div>
              
              {/* <div className={styles.statsCard}>
                <div className={styles.statsIconContainer}>
                  <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
                    <path d="M12 2a10 10 0 1 0 10 10H12V2z" />
                    <path d="M20 10a8 8 0 1 0-16 0" />
                    <path d="M2 10h10v10" />
                  </svg>
                </div>
                <div className={styles.statsContent}>
                  <div className={styles.statsValue}>{statistics.completionRate}%</div>
                  <div className={styles.statsLabel}>Відсоток виконання</div>
                </div> */}
              {/* </div> */}
            </div>
            
            {/* Графік прогресу по проектам */}
            {/* <div className={styles.projectsProgressSection}>
              <h2 className={styles.sectionTitle}>Прогрес проектів</h2>
              
              <div className={styles.projectsProgressList}>
                {statistics.projectsData && statistics.projectsData.length > 0 ? (
                  statistics.projectsData.map((project) => (
                    <div key={project.id} className={styles.projectProgressItem}>
                      <div className={styles.projectInfoHeader}>
                        <div className={styles.projectName}>{project.name}</div>
                        <div className={styles.projectCompletionRate}>
                          {project.completionRate || 0}%
                        </div>
                      </div>
                      
                      <div className={styles.progressBarContainer}>
                        <div 
                          className={styles.progressBar}
                          style={{ width: `${project.completionRate || 0}%` }}
                        ></div>
                      </div>
                      
                      <div className={styles.projectStats}>
                        <div className={styles.projectStat}>
                          <span className={styles.statLabel}>Задачі:</span>
                          <span className={styles.statValue}>
                            {project.filteredCompletedTasksCount || project.completedTasksCount || 0} / {project.filteredTasksCount || project.tasksCount || 0}
                          </span>
                        </div>
                        <div className={styles.projectStat}>
                          <span className={styles.statLabel}>Оновлено:</span>
                          <span className={styles.statValue}>
                            {formatDate(project.updatedAt)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className={styles.emptyState}>
                    <p>Немає проектів для відображення в обраному періоді.</p>
                  </div>
                )}
              </div>
            </div> */}
            
            {/* Список задач з дедлайнами */}
            <div className={styles.upcomingDeadlinesSection}>
              <h2 className={styles.sectionTitle}>Наближаються дедлайни</h2>
              
              <div className={styles.deadlinesList}>
                {upcomingTasks && upcomingTasks.length > 0 ? (
                  upcomingTasks.map((task, idx) => (
                    <div key={`${task.id}-${idx}`} className={styles.deadlineItem}>
                      <div className={styles.deadlineItemHeader}>
                        <div className={styles.deadlineDate}>
                          {task.deadline && formatDate(task.deadline)}
                        </div>
                        <div className={styles.projectBadge}>
                          {task.projectName}
                        </div>
                      </div>
                      <div className={styles.deadlineTitle}>
                        {task.title}
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => router.push(`/dashboard/${task.projectId}`)}
                      >
                        Перейти до задачі
                      </Button>
                    </div>
                  ))
                ) : (
                  <div className={styles.emptyState}>
                    <p>Немає наближених дедлайнів на наступний тиждень.</p>
                  </div>
                )}
              </div>
            </div>
            
            <div className={styles.overdueTasksSection}>
              <h2 className={styles.sectionTitle}>Прострочені задачі</h2>
              
              <div className={styles.overdueList}>
                {overdueTasks && overdueTasks.length > 0 ? (
                  overdueTasks.map((task, idx) => (
                    <div key={`${task.id}-${idx}`} className={styles.overdueItem}>
                      <div className={styles.overdueItemHeader}>
                        <div className={styles.overdueDate}>
                          {task.deadline && formatDate(task.deadline)}
                        </div>
                        <div className={styles.projectBadge}>
                          {task.projectName}
                        </div>
                      </div>
                      <div className={styles.overdueTitle}>
                        {task.title}
                      </div>
                      <div className={styles.overdueActions}>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => router.push(`/dashboard/${task.projectId}`)}
                        >
                          Перейти до задачі
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className={styles.emptyState}>
                    <p>Немає прострочених задач. Чудова робота!</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Повідомлення коли немає даних */}
        {!statistics && !isLoading && (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}>📊</div>
            <h3>Аналітичних даних не знайдено</h3>
            <p>Створіть проекти та задачі, щоб переглянути статистику.</p>
            <Button 
              variant="primary"
              onClick={() => router.push('/dashboard')}
            >
              Перейти до проектів
            </Button>
          </div>
        )}
      </div>
    </MainLayout>
  );
}