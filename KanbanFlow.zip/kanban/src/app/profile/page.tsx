// src/app/profile/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/Button/Button';
import Input from '@/components/ui/Input/Input';
import { auth } from '@/api/api';
import { toast } from 'react-hot-toast';
import styles from './page.module.css';

interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  createdAt: string;
  lastLogin: string;
  isVerified: boolean;
}

type EditingField = 'none' | 'fullName' | 'email';

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [editingField, setEditingField] = useState<EditingField>('none');
  const [isSaving, setIsSaving] = useState(false);
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const [profileForm, setProfileForm] = useState({
    fullName: '',
    email: '',
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [profileErrors, setProfileErrors] = useState<{
    fullName?: string;
    email?: string;
    general?: string;
  }>({});

  const [passwordErrors, setPasswordErrors] = useState<{
    currentPassword?: string;
    newPassword?: string;
    confirmPassword?: string;
    general?: string;
  }>({});

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const res = await auth.me();
        setUser(res.data);
        setProfileForm({
          fullName: res.data.fullName,
          email: res.data.email,
        });
      } catch (error) {
        toast.error('Помилка при завантаженні профілю');
        router.push('/auth/login');
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserData();
  }, [router]);

  const formatDate = (dateString: string) => {
    if (!dateString) return 'Невідомо';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('uk-UA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileForm(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (profileErrors[name as keyof typeof profileErrors]) {
      setProfileErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const startEditing = (field: 'fullName' | 'email') => {
    setEditingField(field);
    setProfileErrors({});
    // Reset form to current user data
    if (user) {
      setProfileForm({
        fullName: user.fullName,
        email: user.email,
      });
    }
  };

  const cancelEditing = () => {
    setEditingField('none');
    setProfileErrors({});
    // Reset form to current user data
    if (user) {
      setProfileForm({
        fullName: user.fullName,
        email: user.email,
      });
    }
  };

  const validateField = (field: 'fullName' | 'email') => {
    const errors: { fullName?: string; email?: string } = {};
    
    if (field === 'fullName') {
      if (!profileForm.fullName.trim()) {
        errors.fullName = 'Ім\'я обов\'язкове';
      }
    }
    
    if (field === 'email') {
      if (!profileForm.email.trim()) {
        errors.email = 'Email обов\'язковий';
      } else if (!/\S+@\S+\.\S+/.test(profileForm.email)) {
        errors.email = 'Введіть коректний email';
      }
    }
    
    setProfileErrors(errors);
    return Object.keys(errors).length === 0;
  };


  const handleSaveField = async (field: 'fullName' | 'email') => {
    // Validate only the current field
    if (!validateField(field) || isSaving) return;
    
    setIsSaving(true);
    try {
      // Send only the updated field (partial update)
      const updateData = field === 'fullName' 
        ? { fullName: profileForm.fullName }
        : { email: profileForm.email };
      
      const res = await auth.updateProfile(updateData as any);
      setUser(prev => prev ? { ...prev, ...res.data } : null);
      setEditingField('none');
      toast.success(`${field === 'fullName' ? 'Ім\'я' : 'Email'} успішно оновлено`);
    } catch (error: any) {
      // Handle server validation errors
      if (error.response?.data?.message) {
        const errorMessage = error.response.data.message;
        
        // Handle array of error messages
        if (Array.isArray(errorMessage)) {
          const errors: { fullName?: string; email?: string; general?: string } = {};
          
          errorMessage.forEach((msg: string) => {
            if (msg.toLowerCase().includes('email')) {
              errors.email = msg;
            } else if (msg.toLowerCase().includes('name') || msg.toLowerCase().includes('fullname')) {
              errors.fullName = msg;
            } else {
              errors.general = msg;
            }
          });
          
          setProfileErrors(errors);
          
          // Show specific error message
          const errorField = field === 'fullName' ? 'fullName' : 'email';
          if (errors[errorField]) {
            toast.error(errors[errorField]);
          } else if (errors.general) {
            toast.error(errors.general);
          }
        } else {
          // Handle single error message
          setProfileErrors({
            [field]: errorMessage,
          });
          toast.error(errorMessage);
        }
      } else {
        const errorMessage = `Помилка при оновленні ${field === 'fullName' ? 'імені' : 'email'}`;
        setProfileErrors({
          [field]: errorMessage,
        });
        toast.error(errorMessage);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordForm(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (passwordErrors[name as keyof typeof passwordErrors]) {
      setPasswordErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const validatePasswordForm = () => {
    const errors: {
      currentPassword?: string;
      newPassword?: string;
      confirmPassword?: string;
    } = {};
    
    if (!passwordForm.currentPassword) {
      errors.currentPassword = 'Введіть поточний пароль';
    }
    
    if (!passwordForm.newPassword) {
      errors.newPassword = 'Введіть новий пароль';
    } else if (passwordForm.newPassword.length < 8) {
      errors.newPassword = 'Пароль має бути не менше 8 символів';
    }
    
    if (!passwordForm.confirmPassword) {
      errors.confirmPassword = 'Підтвердіть новий пароль';
    } else if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      errors.confirmPassword = 'Паролі не співпадають';
    }
    
    setPasswordErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleChangePassword = async () => {
    if (!validatePasswordForm() || isSaving) return;
    
    setIsSaving(true);
    try {
      await auth.changePassword({
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      });
      setShowPasswordForm(false);
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      toast.success('Пароль успішно змінено!');
    } catch (error: any) {
      setPasswordErrors({
        general: error.response?.data?.message || 'Помилка при зміні пароля',
      });
      toast.error('Помилка при зміні пароля');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (window.confirm('Ви впевнені, що хочете видалити свій обліковий запис? Ця дія незворотна.')) {
      setIsDeleting(true);
      try {
        // Implement account deletion API call here
        // await auth.deleteAccount();
        localStorage.removeItem('authToken');
        toast.success('Обліковий запис видалено');
        router.push('/auth/login');
      } catch (error) {
        toast.error('Помилка при видаленні облікового запису');
        setIsDeleting(false);
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    toast.success('Вихід успішний');
    router.push('/auth/login');
  };

  if (isLoading) {
    return (
      <MainLayout user={null} recentProjects={[]} onLogout={handleLogout}>
        <div className={styles.loadingContainer}>
          <div className={styles.spinner} />
          <p>Завантаження профілю...</p>
        </div>
      </MainLayout>
    );
  }

  if (!user) {
    return (
      <MainLayout user={null} recentProjects={[]} onLogout={handleLogout}>
        <div className={styles.errorContainer}>
          <h2>Помилка завантаження профілю</h2>
          <p>Не вдалося завантажити дані користувача.</p>
          <div className={styles.errorActions}>
            <Button variant="primary" onClick={() => window.location.reload()}>
              Оновити сторінку
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              Вийти
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout user={user} recentProjects={[]} onLogout={handleLogout}>
      <div className={styles.profileContainer}>
        <h1 className={styles.profileHeader}>Мій профіль</h1>

        <div className={styles.profileCard}>
          <div className={styles.profileInfo}>
            <h2>{user.fullName}</h2>
            <p className={styles.emailDisplay}>{user.email}</p>
            {user.isVerified ? (
              <div className={`${styles.verificationBadge} ${styles.verified}`}>
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={styles.verificationIcon}>
                  <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
                </svg>
                Підтверджений
              </div>
            ) : (
              <div className={styles.verificationBadge}>
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={styles.verificationIcon}>
                  <path d="M12 8v4m0 4h.01M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Не підтверджений
              </div>
            )}
          </div>

          <div className={styles.infoGrid}>
            <div>
              <div>Дата реєстрації</div>
              <div>{formatDate(user.createdAt)}</div>
            </div>
            <div>
              <div>Останній вхід</div>
              <div>{formatDate(user.lastLogin)}</div>
            </div>
          </div>

          {/* Full Name Field */}
          <div className={styles.profileField}>
            <div className={styles.fieldHeader}>
              <label>Повне ім'я</label>
              {editingField !== 'fullName' && (
                <Button 
                  variant="ghost" 
                  // size="small"
                  onClick={() => startEditing('fullName')}
                  disabled={editingField !== 'none'}
                >
                  Редагувати
                </Button>
              )}
            </div>
            {editingField === 'fullName' ? (
              <>
                <Input
                  name="fullName"
                  value={profileForm.fullName}
                  onChange={handleProfileChange}
                  error={profileErrors.fullName}
                  isRequired
                />
                <div className={styles.fieldActions}>
                  <Button variant="ghost" onClick={cancelEditing}>
                    Скасувати
                  </Button>
                  <Button
                    variant="primary"
                    onClick={() => handleSaveField('fullName')}
                    isLoading={isSaving}
                  >
                    Зберегти
                  </Button>
                </div>
              </>
            ) : (
              <div className={styles.fieldValue}>{user.fullName}</div>
            )}
          </div>

          {/* Email Field */}
          <div className={styles.profileField}>
            <div className={styles.fieldHeader}>
              <label>Email</label>
              {editingField !== 'email' && (
                <Button 
                  variant="ghost" 
                  // size="small"
                  onClick={() => startEditing('email')}
                  disabled={editingField !== 'none'}
                >
                  Редагувати
                </Button>
              )}
            </div>
            {editingField === 'email' ? (
              <>
                <Input
                  name="email"
                  type="email"
                  value={profileForm.email}
                  onChange={handleProfileChange}
                  error={profileErrors.email}
                  isRequired
                />
                <div className={styles.fieldActions}>
                  <Button variant="ghost" onClick={cancelEditing}>
                    Скасувати
                  </Button>
                  <Button
                    variant="primary"
                    onClick={() => handleSaveField('email')}
                    isLoading={isSaving}
                  >
                    Зберегти
                  </Button>
                </div>
              </>
            ) : (
              <div className={styles.fieldValue}>{user.email}</div>
            )}
          </div>
        </div>

        <div className={`${styles.profileCard} ${styles.securityCard}`}>
          <h2>Безпека</h2>
          {showPasswordForm ? (
            <>
              {passwordErrors.general && (
                <div className={styles.errorMessage}>{passwordErrors.general}</div>
              )}
              <Input
                label="Поточний пароль"
                name="currentPassword"
                type="password"
                value={passwordForm.currentPassword}
                onChange={handlePasswordChange}
                error={passwordErrors.currentPassword}
                isRequired
              />
              <Input
                label="Новий пароль"
                name="newPassword"
                type="password"
                value={passwordForm.newPassword}
                onChange={handlePasswordChange}
                error={passwordErrors.newPassword}
                isRequired
              />
              <Input
                label="Підтвердження пароля"
                name="confirmPassword"
                type="password"
                value={passwordForm.confirmPassword}
                onChange={handlePasswordChange}
                error={passwordErrors.confirmPassword}
                isRequired
              />
              <div className={styles.formActions}>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setShowPasswordForm(false);
                    setPasswordErrors({});
                    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
                  }}
                >
                  Скасувати
                </Button>
                <Button
                  variant="primary"
                  onClick={handleChangePassword}
                  isLoading={isSaving}
                >
                  Змінити пароль
                </Button>
              </div>
            </>
          ) : (
            <div className={styles.securityActions}>
              <div className={styles.securityInfo}>
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={styles.securityIcon}>
                  <path d="M12 3c-2.2 0-4 1.8-4 4v2h8V7c0-2.2-1.8-4-4-4z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <rect x="5" y="9" width="14" height="12" rx="2" stroke="currentColor" strokeWidth="2"/>
                  <circle cx="12" cy="15" r="1" fill="currentColor"/>
                </svg>
                <div>
                  <h3>Пароль</h3>
                  <p>Для безпеки рекомендуємо змінювати пароль кожні 3 місяці</p>
                </div>
              </div>
              <Button variant="outline" onClick={() => setShowPasswordForm(true)}>
                Змінити пароль
              </Button>
            </div>
          )}
        </div>

        <div className={`${styles.profileCard} ${styles.dangerZone}`}>
          <h2>Небезпечна зона</h2>
          <div className={styles.dangerInfo}>
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={styles.dangerIcon}>
              <path d="M12 8v4m0 4h.01M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <p>
              Видалення облікового запису призведе до втрати всіх ваших даних, включаючи проекти, завдання та налаштування.
              <br />
              <strong>Ця дія незворотна.</strong>
            </p>
          </div>
          <Button
            variant="danger"
            onClick={handleDeleteAccount}
            isLoading={isDeleting}
          >
            Видалити обліковий запис
          </Button>
        </div>
      </div>
    </MainLayout>
  );
}