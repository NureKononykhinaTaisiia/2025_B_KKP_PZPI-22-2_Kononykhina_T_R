(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_e9b02a00._.js",
  "static/chunks/node_modules_1d92a7ee._.js",
  "static/chunks/src_298b6de5._.css"
],
    source: "dynamic"
});
