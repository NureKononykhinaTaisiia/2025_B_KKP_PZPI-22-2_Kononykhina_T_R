(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1d92a7ee._.js",
  "static/chunks/src_50956268._.js",
  "static/chunks/src_61a55fa0._.css"
],
    source: "dynamic"
});
