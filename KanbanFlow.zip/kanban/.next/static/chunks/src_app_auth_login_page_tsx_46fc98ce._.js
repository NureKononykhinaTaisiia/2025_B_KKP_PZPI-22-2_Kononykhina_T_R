(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1d92a7ee._.js",
  "static/chunks/src_62baccc3._.js",
  "static/chunks/src_0e6037e6._.css"
],
    source: "dynamic"
});
