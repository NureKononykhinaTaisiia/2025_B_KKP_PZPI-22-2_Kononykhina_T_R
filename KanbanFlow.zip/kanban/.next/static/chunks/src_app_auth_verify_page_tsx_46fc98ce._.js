(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1d92a7ee._.js",
  "static/chunks/src_be9a7253._.js",
  "static/chunks/src_713f61a6._.css"
],
    source: "dynamic"
});
