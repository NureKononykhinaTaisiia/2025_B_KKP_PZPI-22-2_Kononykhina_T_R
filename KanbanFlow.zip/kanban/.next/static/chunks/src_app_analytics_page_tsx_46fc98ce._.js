(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_dca96ed5._.js",
  "static/chunks/node_modules_b3ef68cb._.js",
  "static/chunks/src_4d75c081._.css"
],
    source: "dynamic"
});
