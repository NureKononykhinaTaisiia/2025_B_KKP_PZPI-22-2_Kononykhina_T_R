(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/ui/Button/Button.module.css [app-client] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "button": "Button-module__xDwtkW__button",
  "fullWidth": "Button-module__xDwtkW__fullWidth",
  "leftIcon": "Button-module__xDwtkW__leftIcon",
  "loading": "Button-module__xDwtkW__loading",
  "loadingText": "Button-module__xDwtkW__loadingText",
  "rightIcon": "Button-module__xDwtkW__rightIcon",
  "size-lg": "Button-module__xDwtkW__size-lg",
  "size-md": "Button-module__xDwtkW__size-md",
  "size-sm": "Button-module__xDwtkW__size-sm",
  "spin": "Button-module__xDwtkW__spin",
  "spinner": "Button-module__xDwtkW__spinner",
  "variant-danger": "Button-module__xDwtkW__variant-danger",
  "variant-ghost": "Button-module__xDwtkW__variant-ghost",
  "variant-outline": "Button-module__xDwtkW__variant-outline",
  "variant-primary": "Button-module__xDwtkW__variant-primary",
  "variant-secondary": "Button-module__xDwtkW__variant-secondary",
  "variant-success": "Button-module__xDwtkW__variant-success",
});
}}),
"[project]/src/components/ui/Button/Button.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// src/components/ui/Button/Button.tsx
__turbopack_context__.s({
    "Button": (()=>Button),
    "LinkButton": (()=>LinkButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/ui/Button/Button.module.css [app-client] (css module)");
;
;
;
const Button = ({ children, variant = 'primary', size = 'md', isFullWidth = false, isLoading = false, leftIcon, rightIcon, className = '', disabled, ...props })=>{
    const buttonClassName = [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button,
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][`variant-${variant}`],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][`size-${size}`],
        isFullWidth ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fullWidth : '',
        isLoading ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loading : '',
        className
    ].filter(Boolean).join(' ');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: buttonClassName,
        disabled: isLoading || disabled,
        ...props,
        children: [
            isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].spinner
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Button/Button.tsx",
                lineNumber: 52,
                columnNumber: 21
            }, this),
            !isLoading && leftIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftIcon,
                children: leftIcon
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Button/Button.tsx",
                lineNumber: 53,
                columnNumber: 34
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: isLoading ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loadingText : '',
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Button/Button.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            !isLoading && rightIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rightIcon,
                children: rightIcon
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Button/Button.tsx",
                lineNumber: 55,
                columnNumber: 35
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/Button/Button.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
};
_c = Button;
const LinkButton = ({ href, children, isExternal = false, ...buttonProps })=>{
    const linkClassName = [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button,
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][`variant-${buttonProps.variant || 'primary'}`],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][`size-${buttonProps.size || 'md'}`],
        buttonProps.isFullWidth ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fullWidth : '',
        buttonProps.className || ''
    ].filter(Boolean).join(' ');
    if (isExternal) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: href,
            className: linkClassName,
            target: "_blank",
            rel: "noopener noreferrer",
            children: [
                buttonProps.leftIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftIcon,
                    children: buttonProps.leftIcon
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/Button/Button.tsx",
                    lineNumber: 82,
                    columnNumber: 34
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/Button/Button.tsx",
                    lineNumber: 83,
                    columnNumber: 9
                }, this),
                buttonProps.rightIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rightIcon,
                    children: buttonProps.rightIcon
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/Button/Button.tsx",
                    lineNumber: 84,
                    columnNumber: 35
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/Button/Button.tsx",
            lineNumber: 76,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: linkClassName,
        children: [
            buttonProps.leftIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftIcon,
                children: buttonProps.leftIcon
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Button/Button.tsx",
                lineNumber: 94,
                columnNumber: 32
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Button/Button.tsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            buttonProps.rightIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rightIcon,
                children: buttonProps.rightIcon
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Button/Button.tsx",
                lineNumber: 96,
                columnNumber: 33
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/Button/Button.tsx",
        lineNumber: 90,
        columnNumber: 5
    }, this);
};
_c1 = LinkButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "Button");
__turbopack_context__.k.register(_c1, "LinkButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/auth/verify/page.module.css [app-client] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "actions": "page-module__t5D9xa__actions",
  "description": "page-module__t5D9xa__description",
  "emailAddress": "page-module__t5D9xa__emailAddress",
  "emailIcon": "page-module__t5D9xa__emailIcon",
  "error": "page-module__t5D9xa__error",
  "fadeIn": "page-module__t5D9xa__fadeIn",
  "helpLink": "page-module__t5D9xa__helpLink",
  "iconContainer": "page-module__t5D9xa__iconContainer",
  "instruction": "page-module__t5D9xa__instruction",
  "loginLink": "page-module__t5D9xa__loginLink",
  "needHelp": "page-module__t5D9xa__needHelp",
  "pageContainer": "page-module__t5D9xa__pageContainer",
  "slideUp": "page-module__t5D9xa__slideUp",
  "statusMessage": "page-module__t5D9xa__statusMessage",
  "success": "page-module__t5D9xa__success",
  "title": "page-module__t5D9xa__title",
  "verifyCard": "page-module__t5D9xa__verifyCard",
});
}}),
"[project]/src/api/api.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// src/api/api.ts (оновлена версія)
__turbopack_context__.s({
    "analytics": (()=>analytics),
    "auth": (()=>auth),
    "columns": (()=>columns),
    "default": (()=>__TURBOPACK__default__export__),
    "notifications": (()=>notifications),
    "projects": (()=>projects),
    "tasks": (()=>tasks)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hot-toast/dist/index.mjs [app-client] (ecmascript)");
;
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:5005/api';
// Create axios instance with base URL
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json'
    },
    // Add timeout to prevent hanging requests
    timeout: 15000
});
// Add interceptor to append auth token to each request
api.interceptors.request.use((config)=>{
    // Get token from localStorage (if available)
    let token;
    // Use try-catch to handle localStorage access errors (e.g., in SSR context)
    try {
        token = localStorage.getItem('authToken');
    } catch (error) {
        console.error('Error accessing localStorage:', error);
    }
    // If token exists, add it to request headers
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
});
// Add interceptor for error handling
api.interceptors.response.use((response)=>response, (error)=>{
    // Check if error has response
    if (error.response) {
        // Check for 401 Unauthorized error
        if (error.response.status === 401) {
            try {
                // Remove token and redirect to login page
                localStorage.removeItem('authToken');
                // Only redirect in browser environment
                if ("TURBOPACK compile-time truthy", 1) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Сесія закінчилась. Будь ласка, увійдіть знову.');
                    window.location.href = '/auth/login';
                }
            } catch (e) {
                console.error('Error handling unauthorized response:', e);
            }
        } else if (error.response.status === 500) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Сервер тимчасово недоступний. Спробуйте пізніше.');
        }
    } else if (error.request) {
        // The request was made but no response was received
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Немає відповіді від сервера. Перевірте підключення до інтернету.');
    } else {
        // Something happened in setting up the request
        console.error('Request setup error:', error.message);
    }
    return Promise.reject(error);
});
const auth = {
    register: (data)=>api.post('/auth/register', data),
    login: (data)=>api.post('/auth/login', data),
    me: ()=>api.get('/auth/me'),
    // Нові методи для роботи з профілем
    // Оновлення даних профілю користувача
    updateProfile: (data)=>api.put('/auth/profile', data),
    // Зміна пароля
    changePassword: (data)=>api.post('/auth/change-password', data),
    // Завантаження аватара
    uploadAvatar: (formData)=>api.post('/auth/avatar', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }),
    // Видалення аватара
    deleteAvatar: ()=>api.delete('/auth/avatar'),
    // Видалення облікового запису
    deleteAccount: ()=>api.delete('/auth/account'),
    // Отримання недавніх проектів користувача
    getRecentProjects: ()=>api.get('/auth/recent-projects')
};
const projects = {
    getAll: (params)=>api.get('/projects', {
            params
        }),
    getById: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.get(`/projects/${id}`);
    },
    getUserProjects: (limit)=>{
        const params = limit ? {
            limit
        } : undefined;
        return api.get('/projects/user', {
            params
        });
    },
    create: (data)=>api.post('/projects', data),
    update: (id, data)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.put(`/projects/${id}`, data);
    },
    delete: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.delete(`/projects/${id}`);
    },
    updateColumnOrder: (id, columnOrder)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.patch(`/projects/${id}/column-order`, {
            columnOrder
        });
    }
};
const columns = {
    getAll: (projectId)=>{
        // Validate projectId before making request
        if (!projectId || projectId === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.get('/columns', {
            params: {
                projectId
            }
        });
    },
    getById: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid column ID'));
        }
        return api.get(`/columns/${id}`);
    },
    create: (data)=>{
        // Validate projectId before making request
        if (!data.projectId || data.projectId === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.post('/columns', data);
    },
    update: (id, data)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid column ID'));
        }
        return api.put(`/columns/${id}`, data);
    },
    delete: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid column ID'));
        }
        return api.delete(`/columns/${id}`);
    },
    updateTaskOrder: (id, taskIds)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid column ID'));
        }
        return api.patch(`/columns/${id}/task-order`, {
            taskIds
        });
    }
};
const tasks = {
    getAll: (projectId)=>{
        // Validate projectId before making request
        if (!projectId || projectId === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.get('/tasks', {
            params: {
                projectId
            }
        });
    },
    getById: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid task ID'));
        }
        return api.get(`/tasks/${id}`);
    },
    create: (data)=>{
        // Validate ids before making request
        if (!data.projectId || data.projectId === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        if (!data.columnId || data.columnId === 'undefined') {
            return Promise.reject(new Error('Invalid column ID'));
        }
        return api.post('/tasks', data);
    },
    update: (id, data)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid task ID'));
        }
        if (data.columnId && data.columnId === 'undefined') {
            return Promise.reject(new Error('Invalid column ID'));
        }
        return api.put(`/tasks/${id}`, data);
    },
    delete: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid task ID'));
        }
        return api.delete(`/tasks/${id}`);
    },
    move: (id, targetColumnId)=>{
        // Validate ids before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid task ID'));
        }
        if (!targetColumnId || targetColumnId === 'undefined') {
            return Promise.reject(new Error('Invalid target column ID'));
        }
        return api.patch(`/tasks/${id}/move`, {
            targetColumnId
        });
    },
    getUpcoming: (days = 7)=>api.get('/tasks/upcoming', {
            params: {
                days
            }
        }),
    getOverdue: ()=>api.get('/tasks/overdue')
};
const notifications = {
    getAll: ()=>api.get('/notifications'),
    getUnread: ()=>api.get('/notifications/unread'),
    markAsRead: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid notification ID'));
        }
        return api.post(`/notifications/${id}/read`);
    },
    markAllAsRead: ()=>api.post('/notifications/read-all'),
    delete: (id)=>{
        // Validate id before making request
        if (!id || id === 'undefined') {
            return Promise.reject(new Error('Invalid notification ID'));
        }
        return api.delete(`/notifications/${id}`);
    }
};
const analytics = {
    getStatistics: (timeRange = 'month', startDate, endDate)=>{
        const params = {
            timeRange
        };
        if (timeRange === 'custom' && startDate && endDate) {
            params.startDate = startDate;
            params.endDate = endDate;
        }
        return api.get('/analytics/statistics', {
            params
        });
    },
    getActivity: (timeRange = 'month', startDate, endDate)=>{
        const params = {
            timeRange
        };
        if (timeRange === 'custom' && startDate && endDate) {
            params.startDate = startDate;
            params.endDate = endDate;
        }
        return api.get('/analytics/activity', {
            params
        });
    },
    getTasksDistribution: (projectId)=>{
        // Validate projectId before making request
        if (!projectId || projectId === 'undefined') {
            return Promise.reject(new Error('Invalid project ID'));
        }
        return api.get(`/analytics/projects/${projectId}/distribution`);
    },
    getCompletionVelocity: (timeRange = 'month', startDate, endDate)=>{
        const params = {
            timeRange
        };
        if (timeRange === 'custom' && startDate && endDate) {
            params.startDate = startDate;
            params.endDate = endDate;
        }
        return api.get('/analytics/velocity', {
            params
        });
    }
};
const __TURBOPACK__default__export__ = api;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/auth/verify/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>VerifyPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/app/auth/verify/page.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function VerifyPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isResendingEmail, setIsResendingEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [resendStatus, setResendStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    // Отримуємо email з localStorage (встановлений під час реєстрації)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VerifyPage.useEffect": ()=>{
            const savedEmail = localStorage.getItem('verificationEmail');
            if (savedEmail) {
                setEmail(savedEmail);
            } else {
                // Якщо email не знайдено, перенаправляємо на сторінку реєстрації
                router.push('/auth/register');
            }
        }
    }["VerifyPage.useEffect"], [
        router
    ]);
    // Функція для повторного надсилання листа з підтвердженням
    const handleResendEmail = async ()=>{
        setIsResendingEmail(true);
        setResendStatus({});
        try {
            // Викликаємо API для повторного надсилання листа
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["auth"].resendVerification(email);
            setResendStatus({
                success: true,
                message: 'Лист з підтвердженням надіслано повторно!'
            });
        } catch (error) {
            // Обробка помилок
            setResendStatus({
                success: false,
                message: error.response?.data?.message || 'Не вдалося надіслати лист. Спробуйте пізніше.'
            });
        } finally{
            setIsResendingEmail(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pageContainer,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].verifyCard,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconContainer,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].emailIcon,
                        viewBox: "0 0 24 24",
                        width: "64",
                        height: "64",
                        stroke: "currentColor",
                        strokeWidth: "1.5",
                        fill: "none",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"
                            }, void 0, false, {
                                fileName: "[project]/src/app/auth/verify/page.tsx",
                                lineNumber: 67,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                points: "22,6 12,13 2,6"
                            }, void 0, false, {
                                fileName: "[project]/src/app/auth/verify/page.tsx",
                                lineNumber: 68,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/auth/verify/page.tsx",
                        lineNumber: 58,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/auth/verify/page.tsx",
                    lineNumber: 57,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                    children: "Підтвердіть ваш email"
                }, void 0, false, {
                    fileName: "[project]/src/app/auth/verify/page.tsx",
                    lineNumber: 72,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].description,
                    children: "Ми надіслали лист з посиланням для підтвердження на адресу:"
                }, void 0, false, {
                    fileName: "[project]/src/app/auth/verify/page.tsx",
                    lineNumber: 74,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].emailAddress,
                    children: email
                }, void 0, false, {
                    fileName: "[project]/src/app/auth/verify/page.tsx",
                    lineNumber: 78,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].instruction,
                    children: 'Перевірте вашу поштову скриньку та слідуйте інструкціям у листі для завершення реєстрації. Якщо ви не бачите листа, перевірте папку "Спам".'
                }, void 0, false, {
                    fileName: "[project]/src/app/auth/verify/page.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, this),
                resendStatus.message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statusMessage} ${resendStatus.success ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].success : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error}`,
                    children: resendStatus.message
                }, void 0, false, {
                    fileName: "[project]/src/app/auth/verify/page.tsx",
                    lineNumber: 86,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actions,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            onClick: handleResendEmail,
                            isLoading: isResendingEmail,
                            isFullWidth: true,
                            children: "Надіслати лист ще раз"
                        }, void 0, false, {
                            fileName: "[project]/src/app/auth/verify/page.tsx",
                            lineNumber: 92,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/auth/login",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$auth$2f$verify$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loginLink,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "ghost",
                                isFullWidth: true,
                                children: "Повернутися до сторінки входу"
                            }, void 0, false, {
                                fileName: "[project]/src/app/auth/verify/page.tsx",
                                lineNumber: 102,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/auth/verify/page.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/auth/verify/page.tsx",
                    lineNumber: 91,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/auth/verify/page.tsx",
            lineNumber: 56,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/auth/verify/page.tsx",
        lineNumber: 55,
        columnNumber: 5
    }, this);
}
_s(VerifyPage, "10ccCONYyvTWBwAF1SIgtewjflo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = VerifyPage;
var _c;
__turbopack_context__.k.register(_c, "VerifyPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_be9a7253._.js.map