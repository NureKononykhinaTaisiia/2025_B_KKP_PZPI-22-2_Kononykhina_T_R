(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7958ddfe._.js",
  "static/chunks/node_modules_5c75a7c7._.js",
  "static/chunks/src_d5ece957._.css"
],
    source: "dynamic"
});
