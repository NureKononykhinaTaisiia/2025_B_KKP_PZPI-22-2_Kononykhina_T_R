(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_09a0e43f._.js",
  "static/chunks/src_46c52b80._.js",
  "static/chunks/src_938ceebc._.css"
],
    source: "dynamic"
});
